<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
			
		<meta name="description" content="A sidebar menu as seen on the Google Nexus 7 website" />
		<meta name="keywords" content="google nexus 7 menu, css transitions, sidebar, side menu, slide out menu" />
		<meta name="author" content="Codrops" />
		<link rel="shortcut icon" href="../favicon.ico">
		<link rel="stylesheet" type="text/css" href="css/normalize.css" />
		<link rel="stylesheet" type="text/css" href="css/demo.css" />
		<link rel="stylesheet" type="text/css" href="css/component.css" />
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<script src="js/modernizr.custom.js"></script>

	</head>
	


		<div class="container">
			<ul id="gn-menu" class="gn-menu-main">
				<li class="gn-trigger">
					<a class="gn-icon gn-icon-menu"><span>Menu</span></a>
					<nav class="gn-menu-wrapper">
						<div class="gn-scroller">
							<ul class="gn-menu">
								<li class="gn-search-item">
									<li class="gn-search-item">
										<input placeholder="Search" type="search" class="gn-search">
										<a class="gn-icon gn-icon-search"><span>Search</span></a>
									</li>
										<li><a class="gn-icon gn-icon-article" href="profile.php">PROFILE</a></li>
										<li><a class="gn-icon gn-icon-archive"  href="inspaction.php">INSPECTION</a></li>
										<li><a class="gn-icon gn-icon-import"  href="importexcel.php">IMPORT EXCEL</a></li>
										<li><a class="gn-icon gn-icon-download">Downloads</a></li>
										<li><a class="gn-icon gn-icon-cog">Settings</a></li>
										<li><a class="gn-icon gn-icon-help">Help</a></li>
										
								</li>
							</ul>	
						</div>
						<!-- /gn-scroller -->
					</nav>
				</li>
				<li><a href="index.php">HOME</a></li>
				<li><a class="codrops-icon codrops-icon-prev" input type=button onClick='window.history.back()' value='No' ><span>Back</span></a></li>
				<li><a class="codrops-icon codrops-icon-drop" href="logout.php"><span>logout</span></a></li>
			</ul>
			
			<header>