<?php 
session_start();
        if(isset($_POST['username'])){
				//connection
		include('./Connections/connection.php');
				//รับค่า user & password
        $username = $_POST['username'];
        $password = md5($_POST['password']);
       $_SESSION["username"] = $username ;
                $sql="SELECT * FROM member Where username='".$username."' and password='".$password."' ";

                $result = mysqli_query($con,$sql);
      
                if(mysqli_num_rows($result)==1){

                    $row = mysqli_fetch_array($result);

                    $_SESSION["Userid"] = $row["id"];
                    $_SESSION["user"] = $row["firstname"]." ".$row["lastname"];
                    $_SESSION["level"] = $row["level"];

                    if($_SESSION["level"]=="A"){ //ถ้าเป็น admin ให้กระโดดไปหน้า admin_page.php

                      Header("Location: index");

                    }

                    if ($_SESSION["level"]=="A"){  //ถ้าเป็น member ให้กระโดดไปหน้า user_page.php

                      Header("Location: index");

                    }

                }else{
                  echo "<script>";
                      echo "alert(\" user หรือ  password ไม่ถูกต้อง\");"; 
                      echo "window.history.back()";
                  echo "</script>";

                }

      }else{


           Header("Location: login.php"); //user & password incorrect back to login again

      }
?>