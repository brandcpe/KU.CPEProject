var form_data = null;
function uploadFiles() {
    form_data = new FormData();
    var file = document.getElementById("fileUploader") //All files
    for (var i = 0; i < file.files.length; i++) {
        form_data.append('files[]', file.files[i]);
        uploadSingleFile(file.files[i], i, file.files.length);
    }
}

function uploadSingleFile(files, i, max) {
    var xl2json = new ExcelToJSON();
    xl2json.parseExcel(files, i,max);
}

$(document).ready(function () {
    $('input[type=file]').change(function () {
        $('#btnUpload').show();
    });
    $('#btnUpload').click(() => {
        uploadFiles();
    });
    $(document).on('click', '.confirm', function()
    {
        window.location = "index.php";
    });
});

function JSalert(){
	swal("Congrats!", " Upload Excel Success !", "success");
}