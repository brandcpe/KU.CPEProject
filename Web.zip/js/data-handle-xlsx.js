var xlsx_data = [],
    countXlsx = 0;
var ExcelToJSON = function () {
    this.parseExcel = function (file, i, max) {
        var reader = new FileReader();
        reader.onload = function (e) {
            let data = e.target.result;
            var workbook = XLSX.read(data, {
                type: 'binary'
            });
            workbook.SheetNames.forEach(function (sheetName) {
                var XL_row_object = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
                    header: 1
                });
                let qc_test = {
                    "masterTestDetails": [],
                    "masterTestHeaders": {
                        "LocLotNo": null,
                        "LocTotalQTY": null,
                        "LocSampleQTY": null,
                        "LocMatLotNO": null,
                        "LocInspectionDate": null,
                        "LocSample1": null,
                        "LocSample2": null,
                        "LocSample3": null,
                        "LocSample4": null,
                        "LocSample5": null,
                        "LocSample6": null,
                        "LocSample7": null,
                        "LocSample8": null,
                        "LocSample9": null,
                        "LocSample10": null,
                        "LocRemark": null,
                        "PartNO": null,

                    },
                    "inspectTestHeaders": {
                        "LotNO": null,
                        "TotalQTY": null,
                        "SampleQTY": null,
                        "MatLotNO": null,
                        "InspectionDate": null
                    }
                };
                let step = 1,
                    ToleranceCell = 1;
                let columnCellMasterDetails = {
                    "TestNO": null,
                    "TestName": null,
                    "Tolerance": null,
                    "Sample1": null
                };
                var valueMasterDetails = {
                    "TestNO": null,
                    "TestName": null,
                    "Tolerance": null,
                    "StartRow": null,
                    "TestValueTypeID": null,
                    "MinimumValue": null,
                    "MaximumValue": null
                };
                $.each(XL_row_object, function (indexRow, valueRow) {
                    var keyword, lastKeyword = "";
                    if (ToleranceCell % 2 == 1) {
                        valueMasterDetails = {
                            "TestNO": null,
                            "TestName": null,
                            "Tolerance": null,
                            "StartRow": null,
                            "TestValueTypeID": null,
                            "MinimumValue": null,
                            "MaximumValue": null
                        };
                    }

                    $.each(valueRow, function (indexColumn, valueColumn) {
                        if (valueColumn == undefined) return; // ignore undefined cell

                        /** handle position of cell */
                        let fixEngLength = indexColumn;
                        let fixEngText = "";
                        let countEng = 0;
                        while (fixEngLength >= 26) {
                            fixEngLength -= 26;
                            countEng++;
                        }
                        if (countEng) fixEngText = String.fromCharCode(65 + ((countEng - 1) % 26)) + String.fromCharCode(65 + (fixEngLength % 26));
                        else fixEngText = String.fromCharCode(65 + (fixEngLength % 26));
                        let posKeyword = fixEngText + (indexRow + 1);

                        /** keyword for get value to store in database */
                        try {
                            keyword = valueColumn.toString().replace(/[^0-9a-zA-Z]+/g, '');
                        } catch (err) {
                            keyword = "";
                        }

                        /** get PART NO */
                        if (posKeyword == "A1") qc_test.masterTestHeaders.PartNO = valueColumn.split(":")[1];

                        /** step 1: for handle variable to store position and values of master headers and inspection headers*/
                        if (step === 1) {
                            switch (keyword) { //"NO", "TESTMETHOD", "TOLERANCE"
                                case "LOTNO":
                                    qc_test.masterTestHeaders.LocLotNo = posKeyword;
                                    lastKeyword = "LOTNO";
                                    break;
                                case "TOTALQTY":
                                    qc_test.masterTestHeaders.LocTotalQTY = posKeyword;
                                    lastKeyword = "TOTALQTY";
                                    break;
                                case "SAMPLEQTY":
                                    qc_test.masterTestHeaders.LocSampleQTY = posKeyword;
                                    lastKeyword = "SAMPLEQTY";
                                    break;
                                case "MATERIALSLOTNO":
                                    qc_test.masterTestHeaders.LocMatLotNO = posKeyword;
                                    lastKeyword = "MATERIALSLOTNO";
                                    break;
                                case "INSPECTIONDATE":
                                    qc_test.masterTestHeaders.LocInspectionDate = posKeyword;
                                    lastKeyword = "INSPECTIONDATE";
                                    break;
                                case "SAMPLE1":
                                    qc_test.masterTestHeaders.LocSample1 = posKeyword;
                                    columnCellMasterDetails.Sample1 = fixEngText;
                                    break;
                                case "SAMPLE2":
                                    qc_test.masterTestHeaders.LocSample2 = posKeyword;
                                    break;
                                case "SAMPLE3":
                                    qc_test.masterTestHeaders.LocSample3 = posKeyword;
                                    break;
                                case "SAMPLE4":
                                    qc_test.masterTestHeaders.LocSample4 = posKeyword;
                                    break;
                                case "SAMPLE5":
                                    qc_test.masterTestHeaders.LocSample5 = posKeyword;
                                    break;
                                case "SAMPLE6":
                                    qc_test.masterTestHeaders.LocSample6 = posKeyword;
                                    break;
                                case "SAMPLE7":
                                    qc_test.masterTestHeaders.LocSample7 = posKeyword;
                                    break;
                                case "SAMPLE8":
                                    qc_test.masterTestHeaders.LocSample8 = posKeyword;
                                    break;
                                case "SAMPLE9":
                                    qc_test.masterTestHeaders.LocSample9 = posKeyword;
                                    break;
                                case "SAMPLE10":
                                    qc_test.masterTestHeaders.LocSample10 = posKeyword;
                                    break;
                                case "REMARKS":
                                    qc_test.masterTestHeaders.LocRemark = posKeyword;
                                    break;
                                case "NO":
                                    columnCellMasterDetails.TestNO = fixEngText;
                                    break;
                                case "TESTMETHOD":
                                    columnCellMasterDetails.TestName = fixEngText;
                                    break;
                                case "TOLERANCE":
                                    columnCellMasterDetails.Tolerance = fixEngText;
                                    break;
                                default:
                                    if (lastKeyword != "") {
                                        switch (lastKeyword) {
                                            case "LOTNO":
                                                qc_test.inspectTestHeaders.LotNO = valueColumn;
                                                break;
                                            case "TOTALQTY":
                                                qc_test.inspectTestHeaders.TotalQTY = valueColumn;
                                                break;
                                            case "SAMPLEQTY":
                                                qc_test.inspectTestHeaders.SampleQTY = valueColumn;
                                                break;
                                            case "MATERIALSLOTNO":
                                                qc_test.inspectTestHeaders.MatLotNO = valueColumn;
                                                break;
                                            case "INSPECTIONDATE":
                                                qc_test.inspectTestHeaders.InspectionDate = valueColumn;
                                                break;
                                        }
                                        lastKeyword = "";
                                    }
                                    break;
                            }
                        } else if (step === 2) {
                            /**

                             */
                            switch (fixEngText) {
                                case columnCellMasterDetails.TestNO:
                                        valueMasterDetails.TestNO = valueColumn.toString();
                                        valueMasterDetails.StartRow = indexRow + 1;
                                    break;
                                case columnCellMasterDetails.TestName:
                                        valueMasterDetails.TestName = valueColumn;
                                    break;
                                case columnCellMasterDetails.Tolerance:
                                    if ( ToleranceCell % 2 == 0) {
                                        let [min, max] = valueColumn.replace(/[^0-9\.\~]+/g, '').split("~");
                                        if (min != undefined && max != undefined) {
                                            valueMasterDetails.MinimumValue = min;
                                            valueMasterDetails.MaximumValue = max;
                                            valueMasterDetails.TestValueTypeID = 0;
                                        } else {
                                            valueMasterDetails.TestValueTypeID = 1;
                                        }
                                        qc_test.masterTestDetails.push(valueMasterDetails);
                                    } else {
                                        valueMasterDetails.Tolerance = valueColumn;
                                    }
                                    ToleranceCell++;
                                    break;
                            }
                        }
                        if (keyword == "REMARKS") step = 2;
                    });
                });
                xlsx_data.push(qc_test);
            });
            countXlsx++;
            if (countXlsx == max) {
                $.ajax({
                    type: "POST",
                    url: "php/update.php",
                    dataType: "json",
                    data: form_data,
                    contentType: false,
                    processData: false
                }).done(function (d) {
                    console.log("upload success!");
                }).fail(function (a) {
                    console.log("upload fail!");
                });

                $.ajax({
                    type: "POST",
                    url: "php/update.php",
                    dataType: "json",
                    data: "data=" + JSON.stringify(xlsx_data),
                }).done(function (d){
                    JSalert();
                }).fail(function (a) {
                    console.log("send fail!");
                });
            }
        };
        reader.onerror = function (ex) {
            console.log(ex);
        };
        reader.readAsBinaryString(file);
    };
};