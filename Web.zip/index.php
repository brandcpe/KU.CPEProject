
<?php session_start();?>
<?php 
if (!$_SESSION["Userid"]){  //check session

	  Header("Location: login.php"); //ไม่พบผู้ใช้กระโดดกลับไปหน้า login form 

}else{?>

<?php require_once('./Connections/connection.php'); ?>
<?php include ('menubar.php'); ?>

<!DOCTYPE html>
<html lang="en" class="no-js">
	
			
			<h1>ระบบทดสอบชิ้นส่วนตัวอย่าง <span align = "center">Parts Test Report System Company </span></h1>	
			
		

			
		</div>
		<!-- /container -->
		<script src="js/classie.js"></script>
		<script src="js/gnmenu.js"></script>
		<script>
			new gnMenu( document.getElementById( 'gn-menu' ) );
		</script>
	</body>
</html>
<?php }?>