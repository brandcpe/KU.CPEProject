<?php
require "dbconf.php";
$conn = newConnect();
if (isset($_POST["data"])) {
    $json_data = json_decode($_POST["data"], true);
    if (is_array($json_data) or is_object($json_data)) {
        //$sqlInspection = "INSERT INTO `inspect_test_headers` (`MasterTestID`, `LotNO`, `TotalQTY`, `SampleQTY`, `MatLot`, `inspectionDate`) VALUES ";
        $sqlMasterHeaders = "INSERT INTO master_test_headers (`LocLotNO`, `LocTotalQTY`, `LocSampleQTY`, `LocMatLotNO`, `LocSample1`, `LocSample2`, 
        `LocSample3`, `LocSample4`, `LocSample5`, `LocSample6`, `LocSample7`, `LocSample8`, `LocSample9`, `LocSample10`, `LocInspectionDate`, 
        `PartNO`, `LocRemark`) VALUES ";
        $sqlMasterDetails = "INSERT INTO master_test_details (`MasterTestID`,`TestNO`,`TestName`,`StartRow`,`TestValueTypeID`,`MinimumValue`,`MaximumValue`) 
        VALUES ";
        foreach ($json_data as $idx => $jsonObj) {
            /** Master headers values */
            $sqlMasterHeaders .= "('" . $jsonObj["masterTestHeaders"]["LocLotNo"] . "','";
            $sqlMasterHeaders .= $jsonObj["masterTestHeaders"]["LocTotalQTY"] . "','";
            $sqlMasterHeaders .= $jsonObj["masterTestHeaders"]["LocSampleQTY"] . "','";
            $sqlMasterHeaders .= $jsonObj["masterTestHeaders"]["LocMatLotNO"] . "','";
            $sqlMasterHeaders .= $jsonObj["masterTestHeaders"]["LocSample1"] . "','";
            $sqlMasterHeaders .= $jsonObj["masterTestHeaders"]["LocSample2"] . "','";
            $sqlMasterHeaders .= $jsonObj["masterTestHeaders"]["LocSample3"] . "','";
            $sqlMasterHeaders .= $jsonObj["masterTestHeaders"]["LocSample4"] . "','";
            $sqlMasterHeaders .= $jsonObj["masterTestHeaders"]["LocSample5"] . "','";
            $sqlMasterHeaders .= $jsonObj["masterTestHeaders"]["LocSample6"] . "','";
            $sqlMasterHeaders .= $jsonObj["masterTestHeaders"]["LocSample7"] . "','";
            $sqlMasterHeaders .= $jsonObj["masterTestHeaders"]["LocSample8"] . "','";
            $sqlMasterHeaders .= $jsonObj["masterTestHeaders"]["LocSample9"] . "','";
            $sqlMasterHeaders .= $jsonObj["masterTestHeaders"]["LocSample10"] . "','";
            $sqlMasterHeaders .= $jsonObj["masterTestHeaders"]["LocInspectionDate"] . "','";
            $sqlMasterHeaders .= $jsonObj["masterTestHeaders"]["PartNO"] . "','";
            $sqlMasterHeaders .= $jsonObj["masterTestHeaders"]["LocRemark"] . "');";
            if ($conn->query($sqlMasterHeaders) === TRUE) {
                $return["success"] = "Updated master headers!";
            } else {
                $return["error"] = "Error: SQL --> " . $sql . " CONNECT --> " . $conn->error;
            }
            $masterTestID = getMasterTestID($conn);
            foreach ($jsonObj["masterTestDetails"] as $idx2 => $jsonObj2) {
                $sqlMasterDetails .= "($masterTestID,'";
                $quoteCount = substr_count($jsonObj2["TestNO"], "'");
                $TestNO = $jsonObj2["TestNO"];
                for ($i = 0; $i < $quoteCount; $i++) $TestNO .= "'";
                $sqlMasterDetails .= $TestNO . "','";
                $sqlMasterDetails .= $jsonObj2["TestName"] . "','";
                $sqlMasterDetails .= $jsonObj2["StartRow"] . "',";
                $sqlMasterDetails .= $jsonObj2["TestValueTypeID"] . ",";
                if ($jsonObj2["MinimumValue"] == null) $sqlMasterDetails .= "0,";
                else $sqlMasterDetails .= $jsonObj2["MinimumValue"] . ",";
                if ($jsonObj2["MaximumValue"] == null) $sqlMasterDetails .= "0),";
                else $sqlMasterDetails .= $jsonObj2["MaximumValue"] . "),";
            }

            $sqlMasterDetailsFix = rtrim($sqlMasterDetails, ',');
            if ($conn->query($sqlMasterDetailsFix . ";") === TRUE) {
                $return["success"] = "Updated master details!";
            } else {
                $return["error"] = "Error: SQL --> " . $sqlMasterDetailsFix . " CONNECT --> " . $conn->error;
            }
        }
    } else {
        echo "data is not object or array<br><br>";
    }

    /**
     * 
     * Update inspection test headers
     * 
     */
    // select id of master
//     $sqlSelectMasterID = "SELECT MAX(MasterTestID) as ID FROM master_test_headers";
//     $result = $conn->query($sqlSelectMasterID);
//     if ($result->num_rows > 0) {
//         $row = $result->fetch_assoc();
//         $MasterID = $row["ID"];
//     } else {
//         $MasterID = 1;
//     }
//     // insert inspect header
//     // $sql = "INSERT INTO inspect_test_headers (`MasterTestID`, `LotNO`, `TotalQTY`, `SampleQTY`, `MatLot`, `inspectionDate`) 
//     //     VALUES ($MasterID, '$LotNO', '$TotalQTY', '$SampleQTY', '$MatLot', '$InspectionDate')";
//     // if ($conn->query($sql) === TRUE) {
//     //     $return["success"] = "Updated inspection test headers!";
//     // } else {
//     //     $return["error"] = "Error: SQL --> " . $sql . " CONNECT --> " . $conn->error;
//     // }

//     /**
//      * 
//      * Update master test headers
//      * 
//      */
//     // select id of inspect
//     $sqlSelectInspectID = "SELECT MAX(InspectTestID) as ID FROM inspect_test_headers";
//     $result = $conn->query($sqlSelectInspectID);
//     if ($result->num_rows > 0) {
//         $row = $result->fetch_assoc();
//         $inspectID = $row["ID"];
//     } else {
//         $inspectID = 1;
//     }
//     // insert master header
//     $sql = "INSERT INTO master_test_headers (`LocLotNO`, `LocTotalQTY`, `LocSampleQTY`, `LocMatLot`, `LocSample1`, `LocSample2`, 
// `LocSample3`, `LocSample4`, `LocSample5`, `LocSample6`, `LocSample7`, `LocSample8`, `LocSample9`, `LocSample10`, `LocInspectionDate`, 
// `PartNO`, `ExcelFile`, `Remark`) VALUES ('John', 'Doe', 'john@example.com')";
//     // insert inspect details 
//     $sql = "INSERT INTO inspect_test_details (`InspectTestID`)";
//     // if ($conn->query($sql) === TRUE) {
//     //     echo "New record created successfully";
//     // } else {
//     //     echo "Error: " . $sql . "<br>" . $conn->error;
//     // }

    $conn->close();
} else if (isset($_FILES['files']) && !empty($_FILES['files'])) {
    $no_files = count($_FILES["files"]['name']);
    $return = [];
    for ($i = 0; $i < $no_files; $i++) {
        if ($_FILES["files"]["error"][$i] > 0) {
            $er["error"] = "file upload " . $_FILES["files"]["error"][$i];
            array_push($return, $er);
        } else {
            if (file_exists('uploads/' . $_FILES["files"]["name"][$i])) {
                $er["error"] = "File already exists : uploads/" . $_FILES["files"]["name"][$i];
                array_push($return, $er);
            } else {
                $ss["success"] = "File successfully uploaded : uploads/" . $_FILES["files"]["name"][$i];
                array_push($return, $ss);
                move_uploaded_file($_FILES["files"]["tmp_name"][$i], 'uploads/' . $_FILES["files"]["name"][$i]);
            }
        }
    }
} else {
    $return["error"] = "param error";
}
echo json_encode($return);

function getMasterTestID($conn)
{
    /* select id of master test headers */
    $sqlSelectMasterID = "SELECT MAX(MasterTestID) as ID FROM master_test_headers";
    $result = $conn->query($sqlSelectMasterID);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row["ID"];
    } else {
        return 1;
    }
}
