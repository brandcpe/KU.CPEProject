
<?php session_start();?>
<?php 
if (!$_SESSION["Userid"]){  //check session

	  Header("Location: login.php"); //ไม่พบผู้ใช้กระโดดกลับไปหน้า login form 

}else{?>

<?php require_once('./Connections/connection.php'); ?>
<?php include ('menubar.php'); ?>



			
                   
                  <?php
                //query ข้อมูลจากตาราง member: 
				$sql = "SELECT * FROM member WHERE username ='".$_SESSION["username"]."'" 
				
				or die("Error:" . mysqli_error());
                $result = mysqli_query($con,$sql);
                while($row = mysqli_fetch_array($result)) { 
                    ?>
                                       
                                         <tr align="center">
                                         <div class="container">
                                            <h1><?php echo $row['username'];?></h1>
                                            <p></p>
                                            <div class="card" style="width:400px">
                                              <img class="card-img-top" src="images/user.png" alt="Card image" style="width:50%">
                                              <div class="card-body">
                                                <h2 class="card-title"><?php echo $row['name'];?> <?php echo $row['lastname'];?></h2>
                                                <p class="card-text"><?php echo $row['email'];?> <br>
                                                 <?php echo $row['number'];?></p>
                                              </div>
                                            </div>
                                                          
						        		<?php } ?>
				                     

				 
		<!-- /container -->
		<script src="js/classie.js"></script>
		<script src="js/gnmenu.js"></script>
		<script>
			new gnMenu( document.getElementById( 'gn-menu' ) );
		</script>
	</body>
</html>
<?php }?>


