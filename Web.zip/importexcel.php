
<?php session_start();?>
<?php 
if (!$_SESSION["Userid"]){  //check session

	  Header("Location: login.php"); //ไม่พบผู้ใช้กระโดดกลับไปหน้า login form 

}else{?>

<?php require_once('./Connections/connection.php'); ?>

<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
    <script src="js/jquery-3.4.1.min.js"></script>
    	<script src="js/xlsx.full.min.js"></script>
      	<script src="js/index.js"></script>
    	<script src="js/data-handle-xlsx.js"></script>
    	<link rel="stylesheet" href="css/index.css">
    	<link rel="stylesheet" href="css/bootstrap.min.css">
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
		<title>IMPORT EXCEL</title>
		<meta name="description" content="A sidebar menu as seen on the Google Nexus 7 website" />
		<meta name="keywords" content="google nexus 7 menu, css transitions, sidebar, side menu, slide out menu" />
		<meta name="author" content="Codrops" />
		<link rel="shortcut icon" href="../favicon.ico">
		<link rel="stylesheet" type="text/css" href="css/normalize.css" />
		<link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/component.css" />
        <link rel="stylesheet" type="text/css" href="css/sweetalert.css" />
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<script src="js/modernizr.custom.js"></script>
		<script src="js/sweetalert-dev.js"></script>
	</head>
	<body>
		<div class="container">
			<ul id="gn-menu" class="gn-menu-main">
				<li class="gn-trigger">
					<a class="gn-icon gn-icon-menu"><span>Menu</span></a>
					<nav class="gn-menu-wrapper">
						<div class="gn-scroller">
							<ul class="gn-menu">
								<li class="gn-search-item">
									<li class="gn-search-item">
										<input placeholder="Search" type="search" class="gn-search">
										<a class="gn-icon gn-icon-search"><span>Search</span></a>
									</li>
										<li><a class="gn-icon gn-icon-article" href="profile.php">PROFILE</a></li>
										<li><a class="gn-icon gn-icon-archive">INSPECTION</a></li>
										<li><a class="gn-icon gn-icon-import"href="importexcel.php">IMPORT EXCEL</a></li>
										<li><a class="gn-icon gn-icon-photoshop">Photoshop files</a></li>
										<li><a class="gn-icon gn-icon-download">Downloads</a></li>
										<li><a class="gn-icon gn-icon-cog">Settings</a></li>
										<li><a class="gn-icon gn-icon-help">Help</a></li>
								</li>
							</ul>
						</div>
						<!-- /gn-scroller -->
					</nav>
				</li>
				<li><a href="index.php">HOME</a></li>
				<li><a class="codrops-icon codrops-icon-prev"  input type=button onClick='window.history.back()' value='No'><span>Back</span></a></li>
				<li><a class="codrops-icon codrops-icon-drop" href="logout.php"><span>logout</span></a></li>
			</ul>
			<header>

            <h1>IMPORT EXCEL</h1>

	<div style="padding: 20px;">
        <form id="upload_form" enctype="multipart/form-data" method="post">
            <div class="container">
                <div class="row">
                    <div class="col-md-6" style="text-align:right;">
                        <input type="file" style="display: initial;" name="fileUploader[]" id="fileUploader"
                            class="btn btn-default" accept=".xlsx, .xls" multiple>
                    </div>
                    <div class="col-md-6" style="text-align:left;">
                        <input type="button" id="btnUpload" style="display:none" class="btn btn-default" value="Update">
                    </div>
                </div>
            </div>
        </form>
    </div>
                    

        
      

    </div>
		<!-- /container -->
		<script src="js/classie.js"></script>
		<script src="js/gnmenu.js"></script>
		<script>
			new gnMenu( document.getElementById( 'gn-menu' ) );
		</script>
	</body>
</html>
<?php }?>